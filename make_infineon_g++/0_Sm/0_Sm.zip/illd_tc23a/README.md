# iLLD_TC23A

** Infineon Low Level Driver for AURIX TC23xA MCU **

v1.0.1.3.0
