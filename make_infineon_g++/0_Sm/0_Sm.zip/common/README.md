**Common stuff**
---
